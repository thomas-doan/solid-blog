<body>
    <h1>Stupid Blog</h1>
    <p>Le blog qui suis presque tous les principes SOLID</p>
</body>