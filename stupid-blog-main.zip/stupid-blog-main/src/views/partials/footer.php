<footer>
    <p>Made with stupid</p>
</footer>

</html>